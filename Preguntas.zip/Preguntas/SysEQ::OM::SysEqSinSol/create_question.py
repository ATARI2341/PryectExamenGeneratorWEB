import sys
import fractions
import numpy as np
import random
import os

list_dir=os.path.dirname(__file__).split("/")[:-2]
LibraryFolder="/".join(list_dir)
sys.path.append(LibraryFolder)
import LibCreateQuestion

def create_question(DestFolder="/tmp",Points=dict()):
    json_dict=dict()
    substitutions=dict()
    json_dict["Type"]="OM"
    json_dict["Points"]=Points

    for point in Points.items():
        substitutions[point[0]]=(point[1],"[{value}]")

    TemplateFile="ExamTemplate/TemplateSimple.tex"

    Question=r"""
    Considere el siguiente sistema de ecuaciones:

    \begin{align*}
        [a11]x_1+([a12])x_2+([a13])x_3=&[b1]\\
        [a21]x_1+([a22])x_2+([a23])x_3=&[b2]\\
        [a31]x_1+([a32])x_2+([a33])x_3=&[b3]\\
    \end{align*}

    Haciendo operaciones por renglones, lleve a la forma escalonada reducida (método de Gauss-Jordan). 
    En base a su resultado, selecione la opción correcta:
    """

    dict_choices={"Correct":[],"Incorrect":[]}
    #Correct Choices
    choice_a=r"""

    """

    #parameters

    #
    parameters=dict()
    a=random.randint(-3,3)
    parameters["a"]=a
    b=random.randint(-3,3)
    parameters["b"]=b
    c=random.choice([random.randint(-3,-1),random.randint(1,3)])
    parameters["c"]=c
    d=random.randint(-3,3)
    parameters["d"]=d
    e=random.randint(-3,3)
    parameters["e"]=e
    f=random.randint(-3,3)
    parameters["f"]=f
    g=random.choice([random.randint(-3,-1),random.randint(1,3)])
    parameters["g"]=g

    json_dict["Parameters"]=parameters
    #

    I=np.matrix([[1, 0, 1, a],[0, 1, c, b],[0, 0, 0, c]])

    E=np.matrix([[1, 0, 0],[0, 1, 0],[d, 0, 1]]) # R3 -> dR1+R3

    
    A_res=np.matmul(E,I)
    v_b=A_res[:,3]
    A=A_res[0:3,0:3]
    print(v_b,A)
    
    I=np.matrix([[1, 0, 0],[0, 1, 0],[0, 0, 1]])
    A_res=I
    #E=np.matrix([[0, 0, 1],[0, 1, 0],[1, 0, 0]]) # R1<->R3
    U=np.matrix([[1, d, e],[0, 1, f],[0, 0, 1]]) 
    A_res=np.matmul(U,A_res)

    #E=np.matrix([[1, 0, 0],[d, 1, 0],[0, 0, 1]]) # R2 -> dR1+R2
    L=np.matrix([[1, 0, 0],[d, 1, 0],[e, f, 1]]) 
    A_res=np.matmul(L,A_res)
    
    print(A_res)
    
    A=np.matmul(A_res,A)
    v_b=np.matmul(A_res,v_b)

    print((v_b,A))

    for i in range(0,A.shape[0]):
        for j in range(0,A.shape[1]):
            substitutions[f"a{i+1}{j+1}"]=(A[i,j],"{value}")


    for i in range(0,v_b.shape[0]):
        substitutions[f"b{i+1}"]=(v_b[i,0],"{value}")

    substitutions["a"]=(a,"{value}")
    substitutions["b"]=(b,"{value}")
    substitutions["c"]=(c,"{value}")


    choice=r"""
    El sistema de ecuaciones tiene solución única, la cuál está dada por: $x_1=[a]$, $x_2=[b]$, $x_3=[c]$
    """
    dict_choices["Incorrect"].append(choice)

    choice=r"""
    El sistema de ecuaciones tiene solución única, la cuál está dada por: $x_1=[c]$, $x_2=[b]$, $x_3=[a]$
    """
    dict_choices["Incorrect"].append(choice)

    choice=r"""
    El sistema de ecuaciones tiene solución única, la cuál está dada por: $x_1=-([a])$, $x_2=-([b])$, $x_3=-([c])$
    """
    dict_choices["Incorrect"].append(choice)

    correct_choice=r"""
    El sistema de ecuaciones No tiene solución.
    """
    dict_choices["Correct"].append(correct_choice)

    choice=r"""
    El sistema de ecuaciones tiene soluciones infinitas, las cuales estan caracterizadas por : $x_1=[a]+a$, $x_2=[b]+2a$, $x_3=[a]+a$ con $a\in\mathbb{R}$.
    """
    dict_choices["Incorrect"].append(choice)



    question=LibCreateQuestion.create_question(DestFolder,TemplateFile,LibraryFolder,LatexQuestion=Question,dict_choices=dict_choices)
    json_dict["CR"]=question.CR
    question.substitutions(substitutions)
    latex_question=question.write_latex_question_file()
    question.write_json_file(json_dict)
    question.copy_template_file()

    question_name=os.path.dirname(__file__).split("/")[-1]
    return {"latex_question":latex_question,"json_dict":{question_name:json_dict}}


def main():
    create_question(DestFolder=os.path.dirname(__file__),Points={"Pa":10})

if __name__=="__main__":
    main()